<?php
//keep count of how many fields in the forms are valid 


if (isset($_POST["submit"])) {
    $e=$_POST["email"];
    $f=$_POST["firstname"];
    $l=$_POST["lastname"];
    $p=$_POST["password"];
    $conne=mysqli_connect('localhost','root','','assign2');
        
	
		$querye = "INSERT INTO users (password,firstname,lastname,email)  VALUES ('$p', '$f', '$l','$e')";	
       $resulte = mysqli_query($conne, $querye);
    header('location:login.php');
    
    
    
    
    
    
	
}		
?>

<!DOCTYPE html>
<html>
<head>	
	<title>Create Profile</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link href="css/animate.css" rel="stylesheet" />
<link href="css/main.css" rel="stylesheet" />
</head>
<body>
	<div class="container">
		<h2 class = "animated fadeInDownBig"> Create Profile</h2>
		<hr>
		<form action ='#' method = 'post'   class = "animated fadeIn form">
			<div class="form-group">
			    <label>USN:</label><br>
			    <input type="text"  name = 'email' value = "">
	        </div>
			<div class="form-group">
				<label>First Name:</label><br>
				<input type="text"  name = 'firstname' value = "">
			</div>				  
		    <div class="form-group">
				<label>Last Name:</label><br>
				<input type="text" name = 'lastname' value = "">
		    </div>
		    <div class="form-group">
				<label>Set Password:</label><br>
				<input type="password" name = 'password' value = "">
		    </div>
		    <button type ="submit" name ="submit"class="btn btn-default">Submit</button> 
		    <button type ="submit" class ="btn btn-default" formaction ="index.php">Back</button>
		</form>		
	</div>
</body>
</html>