<!DOCTYPE html>
<html>
<title>Home Page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link href="css/main.css" rel="stylesheet" />
<link href="css/animate.css" rel="stylesheet" />

	<body>

		<div class="container">

			<br>
			<div class = "animated fadeInDownBig">
			<h2 > Welcome to Event Manager! </h2>
			<h2> What would you like to do ? </h2>
			</div>
					<br>
					<hr>
			<label class = "options animated fadeInRight">Have an existing account ?</label><br><br>
			<a href = "login.php" class ="btn btn-default animated fadeIn">Log in</a>
					<br>
					<hr>
					<br>
			<label class ="options animated fadeInRight" >Don't have an account yet ?</label><br><br>
			<a href = "create.php" class = "btn btn-default animated fadeIn">Create One</a>

	</div>
	</body>
</html>

