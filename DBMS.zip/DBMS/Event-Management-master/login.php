
<html>
<head>
<title>Login Page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link href="css/animate.css" rel="stylesheet" />
<link href="css/main.css" rel="stylesheet" />
<body>
	<div class="container">
		<h3 class = "animated fadeInDownBig"> Login page</h3>
		<hr>
		<div class="form-group animated fadeIn">
		<form action = "profile.php" method = "POST" class = "form-inline">
			<label>USN</label>
			<input type ="text" name ="email" value = "">

			<label>Password</label>
			<input type ="password" name ="password" value = "">
			<input type ="submit" class = "btn btn-default" value ="login">
			<br>
			<br>
			<hr>
			<button class = "btn btn-default" formaction= "index.php">Back</button>
		</form>
	    </div>
    </div>
</body>
</html>