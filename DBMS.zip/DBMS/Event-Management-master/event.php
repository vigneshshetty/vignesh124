<?php
if(isset($_POST["imran"]) && isset($_POST["im1"]) && isset($_POST["im2"]) && isset($_POST["im3"])){
    $name=$_POST["imran"];
        $date=$_POST["im1"];
        $loc=$_POST["im2"];
        $cap=$_POST["im3"];
    $conne=mysqli_connect('localhost','root','','assign2');
        
	
		$querye = "INSERT INTO events (name, date, location, capacity) VALUES ('$name', '$date', '$loc',$cap)";	
       $resulte = mysqli_query($conne, $querye);
    echo " Added success";
}
?>
<button style="position:absolute; right:0;" type="submit" onclick="location.href='Logout.php' ">Logout</button>
<center><div>
    <br><br><br><br>
<form method="post" action="#">
<b>NAME:</b><input type='text' name='imran' size='35' value=''/>
<br><br>
<b>DATE:</b><input type='text' name='im1' size='35' value=''/>
<br><br>
<b>LOCATION:</b><input type='text' name='im2' size='35' value=''/>
<br><br>
<b>CAPACITY:</b><input type='text' name='im3' size='35' value=''/>
<br><br>

<input type="submit" value="UPLOAD"/>
</form>
</div>
<button  type="submit" onclick="location.href='admin.php' ">BACK</button></center>

