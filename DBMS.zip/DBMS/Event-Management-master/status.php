<button style="position:absolute; right:0;" type="submit" onclick="location.href='Logout.php' ">Logout</button><br>
<?php
if (isset($_POST["vig"])){
    $id=$_POST["vig"];

$conn= mysqli_connect('localhost','root','','assign2');
    echo "<h2> Request Under Process :</h2>";
$sql="select event_id as nm from registration where confirmed=0 and user_id=$id";
$res=mysqli_query($conn,$sql);
    
 while($row=mysqli_fetch_assoc($res)){
    
     $s=$row['nm'];
     
     $sql1="select * from events where id=$s";
$res1=mysqli_query($conn,$sql1);
 while($row1 = mysqli_fetch_array($res1)){
     $s1=$row1['name'];
     ?>
                    <strong ><?php 
						echo $s1;
					?></strong><br>
<?php
 }
 }
    
     echo "<h2> Request Accepted :</h2>";
$sql="select event_id as nm from registration where confirmed=1 and user_id=$id";
$res=mysqli_query($conn,$sql);
    
 while($row=mysqli_fetch_assoc($res)){
    
     $s=$row['nm'];
     
     $sql1="select * from events where id=$s";
$res1=mysqli_query($conn,$sql1);
 while($row1 = mysqli_fetch_array($res1)){
     $s1=$row1['name'];
     ?>
                    <strong ><?php 
						echo $s1;
					?></strong><br>
<?php
 }
 }
    
     echo "<h2> Request Deleted :</h2>";
$sqle="select event_id as nm from registration where confirmed=2 and user_id=$id";
$rese=mysqli_query($conn,$sqle);
    
 while($rowe=mysqli_fetch_assoc($rese)){
    
     $se=$rowe['nm'];
     
     $sql1e="select * from events where id=$se";
$res1e=mysqli_query($conn,$sql1e);
 while($row1e = mysqli_fetch_array($res1e)){
     $s1e=$row1e['name'];
     ?>
                    <strong ><?php 
						echo $s1e;
					?></strong><br>
<?php
 }
 }
    
 }
?>
